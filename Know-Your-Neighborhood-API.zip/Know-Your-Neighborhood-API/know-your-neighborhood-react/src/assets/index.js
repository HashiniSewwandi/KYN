import facebookLogo from "./images/facebook.png";
import userDefault from "./images/user-default.png";
import open from "./images/open.jpg";
import store1 from "./images/store1.jpg";
import store2 from "./images/store2.jpg";
import indomaret from "./images/indomaret.jpg";
import circleK from "./images/circle-k.jpg";
import hero from "./images/hero.jpg";
import hero2 from "./images/hero2.jpg";
import contact from "./images/contact.jpg";

export {
  facebookLogo,
  userDefault,
  open,
  store1,
  store2,
  indomaret,
  circleK,
  hero,
  hero2,
  contact,
};
