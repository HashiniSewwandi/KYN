import React from "react";
import { hero } from "../../assets";


const Hero = () => {
  return (
    <section className="grid md:grid-cols-2 mt-10 h-max">
      <div className="flex flex-col justify-center mr-0 md:mr-8">
        <h2 className="font-extrabold text-3xl md:text-4xl font-inter">
          Welcome to
        </h2>
        <h2 className="font-extrabold text-3xl md:text-4xl font-inter">
          <strong>Know Your Neighborhood</strong>
        </h2><br></br><br></br>
        <p className="max-w-[400px] text-gray-600 font-medium mt-1">
        KYN is a sequence of supermarkets in sri lanka .
             it is one of three retail operators on the islands along Cargills food town and Arpico SupCenter.
              Get the excellent price of cash with the aid of purchasing online with Keels where freshness in assured.
               shop on keella online and get your purchased deliverd to our home.
        </p>
        <div className="flex my-5 max-w-[550px]">
        <br></br><br></br>
                Our ever-growing product range is made to provide our customers, customers who know their neighbors, with a range of choices.
                We are also committed to providing a shopping experience based on our principles unlike any Walmart store, 
                Neighborhood Market or Sam's Club.<br></br> We also believe that we can provide customers with consistent access to the products they need.
                Get to know your neighborhood to explore the stores around you.<br></br>
          
        </div>
      </div>
      <img
        src={hero}
        alt=""
        className="rounded-3xl lg:rounded-[150px] lg:rounded-tl-[60px] lg:rounded-br-[60px] shadow-lg 
        cursor-pointer brightness-95 hover:brightness-90 transition duration-150"
      />
    </section>
  );
};

export default Hero;
