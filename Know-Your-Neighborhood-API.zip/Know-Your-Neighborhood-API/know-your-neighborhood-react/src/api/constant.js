export const BASE_URL = "http://localhost:8080/api";
export const FACEBOOK_URL =
  "http://localhost:8080/oauth2/authorize/facebook?redirect_uri=http://localhost:3000/oauth2/redirect";
