package com.lithan.kyn.entity;

public enum EAuthProvider {
  local,
  google,
  facebook
}
